
/* This is just a small test to check whether Assimp's API compiles from C */

#include <assimp/postprocess.h>
#include <assimp/scene.h>
#include <assimp/version.h>
#include <assimp/config.h>
#include <assimp/cimport.h>
#include <assimp/cexport.h>
