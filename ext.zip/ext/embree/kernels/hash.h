// Copyright 2009-2021 Intel Corporation
// SPDX-License-Identifier: Apache-2.0

#define RTC_HASH "ae029e2ff83bebbbe8742c88aba5b0521aba1a23"
